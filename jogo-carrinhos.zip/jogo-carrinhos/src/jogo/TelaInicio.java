package jogo;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class TelaInicio extends JFrame {

	protected TelaInicio() {
		super("Escolha a cor do seu carro!");
		new Thread(() -> {
			try {
				SwingUtilities.invokeAndWait(() -> {
					setarLayout();
					adicionarBotoes();
					setVisible(true);

				});
			} catch (Exception e) {

			}
		}).start();

	}

	private void adicionarBotoes() {
		JButton b1 = new JButton();
		JButton b2 = new JButton();
		JButton b3 = new JButton();
		JButton b4 = new JButton();

		b1.setBackground(Color.blue);
		b2.setBackground(Color.red);
		b3.setBackground(Color.yellow);
		b4.setBackground(Color.green);

		b1.setForeground(Color.black);
		b2.setForeground(Color.black);
		b3.setForeground(Color.black);
		b4.setForeground(Color.black);

		final Font font = new Font("Arial", Font.PLAIN, 30);

		b1.setFont(font);
		b2.setFont(font);
		b3.setFont(font);
		b4.setFont(font);

		b1.addActionListener(e -> {
			PainelPista.IDCarroEscolhido = 1;
			dispose();
			try {
				new Corrida();
			} catch (Exception e1) {
			}
		});
		b2.addActionListener(e -> {
			PainelPista.IDCarroEscolhido = 2;
			dispose();
			try {
				new Corrida();
			} catch (Exception e1) {
			}
		});
		b3.addActionListener(e -> {
			PainelPista.IDCarroEscolhido = 3;
			dispose();
			try {
				new Corrida();
			} catch (Exception e1) {
			}
		});
		b4.addActionListener(e -> {
			PainelPista.IDCarroEscolhido = 4;
			dispose();
			try {
				new Corrida();
			} catch (Exception e1) {
			}
		});

		add(b1);
		add(b2);
		add(b3);
		add(b4);

	}

	private void setarLayout() {
		setSize(900, 510);
		setLocationRelativeTo(null);
		setLayout(new GridLayout(2, 2));

	}

}
