package jogo;

import java.awt.BorderLayout;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PainelPista extends JPanel {

	protected static Pista pista;
	protected static LinhaChegada linhaChegada;
	protected static int IDCarroEscolhido = -1;
	protected static Carro carroEscolhido = null;

	PainelPista() throws Exception {
		setarLayout();
	}

	protected void setarLayout() throws Exception {
		setLayout(new BorderLayout());
		add(linhaChegada = new LinhaChegada(), BorderLayout.EAST);
		add(pista = new Pista(), BorderLayout.CENTER);
	}

}
