package jogo;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

@SuppressWarnings("serial")
public class Carro extends JLabel {

	public final Color cor;
	private final int ID;
	
	protected Carro(Color cor, int id) throws Exception {
		this.ID = id;
		this.cor = cor;
		setText("o^o");
		setForeground(cor);
		setFont(new Font("System", Font.PLAIN, 20));
	}

	protected boolean avancar() {
		setBounds(getX() + 5, getY(), getWidth(), getHeight());
		if (getX() == 840) {
			return true;
		}
		return false;
	}

	protected int getId() {
		return this.ID;
	}

	protected void informarCarroUltrapassouLinhaChegada() {
		setBounds(getX() - 45, getY(), getWidth(), getHeight());
		setText(Pista.lugar + "° lugar");
		if (Pista.lugar == 1) {
			Pista.vencedor = this;
		}
		Pista.lugar++;
	}

}
