package jogo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class Pista extends JPanel {

	private final List<Carro> carros = new ArrayList<>(4);
	private final Random sorteador = new Random();
	protected static Carro vencedor = null;
	protected Carro carroEscolhido = null;
	protected static int lugar = 1;
	
	protected Pista() throws Exception {
		setLayout(null);
		organizarPista();
		disporCarrosNaPista();
	}

	private void disporCarrosNaPista() throws Exception {
		Carro c1 = new Carro(Color.blue, 1);
		Carro c2 = new Carro(Color.red, 2);
		Carro c3 = new Carro(Color.yellow, 3);
		Carro c4 = new Carro(Color.green, 4);
		c1.setBounds(5, 0, 200, 100);
		add(c1);
		carros.add(c1);
		c2.setBounds(5, 100, 200, 100);
		add(c2);
		carros.add(c2);
		c3.setBounds(5, 200, 200, 100);
		add(c3);
		carros.add(c3);
		c4.setBounds(5, 300, 200, 100);
		add(c4);
		carros.add(c4);

	}

	protected void comecarCorrida() throws Exception {
		do {
			int aleatorio = sorteador.nextInt(carros.size());
			Carro carro = carros.get(aleatorio);
			if (carro.avancar()) {
				PainelPista.linhaChegada.mudarParaCorDoCarro(carro);
				setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(carro.cor, 4), "Pista de corrida",
						TitledBorder.CENTER, TitledBorder.BELOW_TOP, new Font("System", Font.ITALIC, 20), Color.black));
				carro.informarCarroUltrapassouLinhaChegada();
				carros.remove(carro);
			}
			int delay = sorteador.nextInt(30);
			Thread.sleep(delay);

		} while (corridaNaoFoiConcluida());

		String msg = vencedor.getId() == PainelPista.IDCarroEscolhido ? "Parabéns!!!" : "Talvez na próxima.";
		
		Thread.sleep(500);
		PainelPista.linhaChegada.setBackground(Color.black);
		setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black, 4), msg,
				TitledBorder.CENTER, TitledBorder.BELOW_TOP, new Font("Courier", Font.ITALIC, 30), vencedor.cor));

	}

	private static boolean corridaNaoFoiConcluida() {
		return lugar != 5;
	}

	private void organizarPista() throws Exception {
		setSize(new Dimension(1400, 450));
		setBackground(new Color(80, 80, 80));
		setOpaque(true);
		setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black, 4), "Pista de corrida",
				TitledBorder.CENTER, TitledBorder.BELOW_TOP, new Font("System", Font.ITALIC, 20), Color.black));
	}

}
