package jogo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class Corrida extends JFrame {

	private Thread carregarTela;
	protected static Thread comecarCorrida;
	private JButton botaoCorrida = null;

	protected Corrida() throws Exception {
		this.carregarTela = new Thread(() -> {
			setSize(900, 510);
			setLayout(new BorderLayout());
			setLocationRelativeTo(null);
			setResizable(false);
			try {
				SwingUtilities.invokeAndWait(() -> {
					try {
						add(new PainelPista(), BorderLayout.CENTER);
					} catch (Exception e) {
						e.printStackTrace();
					}
					setDefaultCloseOperation(DISPOSE_ON_CLOSE);
					adicionarBotaoComecarCorrida();
				});
				setVisible(true);
			} catch (InvocationTargetException | InterruptedException e) {
				e.printStackTrace();
			}
		});

		comecarCorrida = new Thread(() -> {
			botaoCorrida.setText("Finalizar");
			botaoCorrida.setBackground(Color.red);
			botaoCorrida.addActionListener(e -> {
				dispose();
			});
			try {
				PainelPista.pista.comecarCorrida();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});

		carregarTela.start();
	}

	private void adicionarBotaoComecarCorrida() {
		botaoCorrida = new JButton("Começar");
		botaoCorrida.setSize(900, 80);
		botaoCorrida.setFont(new Font("Arial", Font.PLAIN, 18));
		botaoCorrida.setBackground(Color.white);
		botaoCorrida.setForeground(Color.DARK_GRAY);
		botaoCorrida.addActionListener(e -> {
			try {
				comecarCorrida.start();
			} catch (Exception e1) {
			}

		});
		add(botaoCorrida, BorderLayout.SOUTH);
	}

}
