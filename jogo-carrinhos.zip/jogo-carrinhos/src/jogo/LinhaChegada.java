package jogo;

import java.awt.Color;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class LinhaChegada extends JPanel {

	public LinhaChegada() {
		setBackground(Color.black);
		setSize(100, 50);
	}

	public void mudarParaCorDoCarro(Carro carro) {
		setBackground(carro.cor);
	}

}
